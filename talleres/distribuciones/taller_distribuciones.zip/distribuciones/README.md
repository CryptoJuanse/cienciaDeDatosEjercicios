# Taller de Dsitribuciones

Taller donde se construyen diferentes distribuciones de datos, se gráfica en histogramas y se obtienen unas conclusiones.

## Integrantes

- ANDRÉS DAVID BECERRA DIMATÉ - 20192020074
- JUAN SEBASTIAN ROMERO VELEZ - 20192020067
- SERGIO LUIS RODRIGUEZ ORTIZ - 20192020060

## Instrucciones

1. Añadir el archivo `Taller_de_distribuciones.ipynb` a drive y ejecutar en un Google Colaboratory.
2. Ejecutar las diferente partes de código.

## Recursos

Colab: https://colab.research.google.com/drive/1hcm1WbXqf2MSpzeGVGtMGN1KHn5zsgHL?usp=sharing

