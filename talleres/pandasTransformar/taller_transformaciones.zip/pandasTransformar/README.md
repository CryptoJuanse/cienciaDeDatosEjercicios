# Taller de Transformaciones

Taller donde se aplican diferentes transformaciones a conjuntos de datos.

## Integrantes

- ANDRÉS DAVID BECERRA DIMATÉ - 20192020074
- JUAN SEBASTIAN ROMERO VELEZ - 20192020067
- SERGIO LUIS RODRIGUEZ ORTIZ - 20192020060

## Instrucciones

1. Para observar la transformacion que puede observar en el nombre del archivo debe abrirlo en un editor de código e ejecutar el archivo `nombre.py` Algunas de estos editores pueden ser:
    - Spyder.
    - Visual Studio Code.
    - VSCodium
    - Vim (Ejecutar en terminal)

