# Taller de Visualización

Taller donde se evidencia la construcción de diferentes gráficas con 3 conjuntos de datos.

## Integrantes

- ANDRÉS DAVID BECERRA DIMATÉ - 20192020074
- JUAN SEBASTIAN ROMERO VELEZ - 20192020067
- SERGIO LUIS RODRIGUEZ ORTIZ - 20192020060

## Instrucciones

1. Añadir el archivo `Visualización_de_datos.ipynb` a drive y ejecutar en un Google Colaboratory.
2. Subir los csv en la ruta `csv/`.
3. Ejecutar las diferente partes de código.

## Recursos

Colab: https://colab.research.google.com/drive/1th_3ERNF7FXVztjQzZ4wuOn0dOfMMxqr?usp=sharing

